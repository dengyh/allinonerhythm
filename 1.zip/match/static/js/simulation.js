$(function() {
	$('#again').click(function() {
		window.location.href = "/simulation/";
	});
});